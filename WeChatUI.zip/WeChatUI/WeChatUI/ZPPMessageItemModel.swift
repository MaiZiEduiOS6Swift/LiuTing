//
//  ZPPMessageItemModel.swift
//  WeChatUI
//
//  Created by 鹏 朱 on 15/10/25.
//  Copyright © 2015年 鹏 朱. All rights reserved.
//

import UIKit

class ZPPMessageItemModel: NSObject {
    var avatarName:String!
    var isSent:Bool!
    var msgString:String!
    var msgItemController:ZPPMessageItemController!

}
